package com.example.mynotesapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import com.example.mynotesapp.adapter.NoteAdapter;
import com.example.mynotesapp.database.NoteDatabase;
import com.example.mynotesapp.model.Note;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton btnAdd;
    NoteAdapter adapter;
    List<Note> notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerViewNotes);
        btnAdd = findViewById(R.id.btnAddNote);

        loadNotes();

        btnAdd.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AddNoteActivity.class)));
    }

    private void loadNotes() {
        notes = NoteDatabase.getInstance(this).noteDao().getAllNotes();
        adapter = new NoteAdapter(this, notes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes(); // refresh list after add/edit/delete
    }
}
