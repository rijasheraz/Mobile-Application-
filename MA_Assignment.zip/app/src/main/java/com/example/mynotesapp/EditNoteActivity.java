package com.example.mynotesapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import com.example.mynotesapp.database.NoteDatabase;
import com.example.mynotesapp.model.Note;

public class EditNoteActivity extends AppCompatActivity {

    EditText edtTitle, edtContent;
    Button btnUpdate, btnDelete;
    int noteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        edtTitle = findViewById(R.id.edtTitle);
        edtContent = findViewById(R.id.edtContent);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        // receive data from intent
        noteId = getIntent().getIntExtra("id", -1);
        String title = getIntent().getStringExtra("title");
        String content = getIntent().getStringExtra("content");

        edtTitle.setText(title);
        edtContent.setText(content);

        btnUpdate.setOnClickListener(v -> {
            String newTitle = edtTitle.getText().toString().trim();
            String newContent = edtContent.getText().toString().trim();
            Note note = new Note(newTitle, newContent);
            note.setId(noteId);
            NoteDatabase.getInstance(this).noteDao().update(note);
            finish();
        });

        btnDelete.setOnClickListener(v -> {
            Note note = new Note(edtTitle.getText().toString(), edtContent.getText().toString());
            note.setId(noteId);
            NoteDatabase.getInstance(this).noteDao().delete(note);
            finish();
        });
    }
}
