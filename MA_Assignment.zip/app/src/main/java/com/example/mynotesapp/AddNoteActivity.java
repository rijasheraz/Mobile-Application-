package com.example.mynotesapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mynotesapp.database.NoteDatabase;
import com.example.mynotesapp.model.Note;

public class AddNoteActivity extends AppCompatActivity {

    private EditText edtTitle, edtContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        //  Initialize UI components
        edtTitle = findViewById(R.id.edtTitle);
        edtContent = findViewById(R.id.edtContent);
        Button btnSave = findViewById(R.id.btnSave);

        // Save note button click
        btnSave.setOnClickListener(v -> {
            String title = edtTitle.getText().toString().trim();
            String content = edtContent.getText().toString().trim();

            // Validation — at least one field must not be empty
            if (title.isEmpty() && content.isEmpty()) {
                Toast.makeText(this, "Please enter a note!", Toast.LENGTH_SHORT).show();
            } else {
                Note note = new Note(title, content);
                NoteDatabase.getInstance(this).noteDao().insert(note);
                Toast.makeText(this, "Note saved successfully!", Toast.LENGTH_SHORT).show();
                finish(); // close activity and go back to MainActivity
            }
        });
    }
}
